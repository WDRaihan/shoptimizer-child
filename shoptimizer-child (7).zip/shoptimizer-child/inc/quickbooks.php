<?php

/* Quickbooks credentials form*/
function quickbooks_integration_cb(){
	if( isset( $_POST['qb_setting_btn'] ) ){
		update_option('qb_client_id', sanitize_text_field($_POST['qb_client_id']));
		update_option('qb_client_secret', sanitize_text_field($_POST['qb_client_secret']));
		update_option('qb_redirect_url', sanitize_url($_POST['qb_redirect_url']));
		
		echo '<p class="notice notice-success settings-error is-dismissible" style="padding:10px">The form has been saved successfully.</p>';
	}
	?>
<form method="post" action="">
	<table class="form-table" role="presentation">
		<tbody>
			<tr>
				<th scope="row">Client ID</th>
				<td><input style="width:300px" type="password" name="qb_client_id" placeholder="Enter Client ID" value="<?php echo esc_html(get_option('qb_client_id')); ?>"></td>
			</tr>
			<tr>
				<th scope="row">Client Secret</th>
				<td><input style="width:300px;" type="password" id="qb_client_secret" placeholder="Enter Client Secret" name="qb_client_secret" value="<?php echo esc_html(get_option('qb_client_secret')); ?>"></td>
			</tr>
			<tr>
				<th scope="row">Redirect URL</th>
				<td><input style="width:300px;" type="text" id="qb_redirect_url" name="qb_redirect_url" value="<?php echo esc_url(get_option('qb_redirect_url')); ?>"></td>
			</tr>
		</tbody>
	</table>
	<input type="submit" name="qb_setting_btn" value="Save">
</form>
<?php
}

/* QuickBooks integration status */
function quickbooks_refresh_token_validation($refreshToken = ''){
	$user_id = get_current_user_id();
	$quickbooks_credentials = get_user_meta($user_id, 'quickbooks_api', true);
	
	if($refreshToken == ''){
		
		if( is_array($quickbooks_credentials) && !empty($quickbooks_credentials['refresh_token']) ){
			$refreshToken = $quickbooks_credentials['refresh_token'];
		}else{
			return 'false';
		}
	}
	
	$tokenUrl = 'https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer';
	$clientId = get_option('qb_client_id');
	$clientSecret = get_option('qb_client_secret');

	$authHeader = base64_encode("$clientId:$clientSecret");

	$postFields = [
		'grant_type' => 'refresh_token',
		'refresh_token' => $refreshToken,
	];

	$ch = curl_init($tokenUrl);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postFields));
	curl_setopt($ch, CURLOPT_HTTPHEADER, [
		"Authorization: Basic $authHeader",
		'Content-Type: application/x-www-form-urlencoded',
	]);

	$response = curl_exec($ch);
	$httpStatus = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	curl_close($ch);

	if ($httpStatus == 200) {
		return 'true';
	}else{
		return 'false';
	}
}

/* Get QuickBooks Access Token */
function quickbooks_get_vendor_access_token(){
	$user_id = get_current_user_id();
	$quickbooks_credentials = get_user_meta($user_id, 'quickbooks_api', true);
	
	if (empty($quickbooks_credentials['refresh_token'])) {
		return false;
	}
	
	$tokenUrl = 'https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer';
	$clientId = get_option('qb_client_id');
	$clientSecret = get_option('qb_client_secret');
	
	$refreshToken = $quickbooks_credentials['refresh_token'];

	$authHeader = base64_encode("$clientId:$clientSecret");

	$postFields = [
		'grant_type' => 'refresh_token',
		'refresh_token' => $refreshToken,
	];

	$ch = curl_init($tokenUrl);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postFields));
	curl_setopt($ch, CURLOPT_HTTPHEADER, [
		"Authorization: Basic $authHeader",
		'Content-Type: application/x-www-form-urlencoded',
	]);

	$response = curl_exec($ch);
	$httpStatus = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	curl_close($ch);

	if ($httpStatus == 200) {
		$tokenData = json_decode($response, true);
		return $tokenData['access_token'];
	}
}

/* Send shipment to quickbooks */
add_action( 'dokan_order_shipping_status_tracking_new_added', 'send_shipment_to_quickbooks', 11, 4 );
function send_shipment_to_quickbooks($post_id, $tracking_info, $user_id, $shipment_id){
	$qb_err = '';
	
	$qb_validation = quickbooks_refresh_token_validation();
	if($qb_validation == 'false'){
		$qb_err = 'error';
	}
	
	$quickbooks_user = get_post_meta( $post_id, 'quickbooks_customer', true );
	if( $quickbooks_user == '' ){
		//die("Error: Missing Quickbooks User.");
		$qb_err = 'error';
		$sync_status = array(
			'status' => 'error',
			'message' => 'QuickBooks sync failed. Please contact support.'
		);
		update_post_meta( $post_id, 'quickbooks_shipment_sync_status', $sync_status );
		mezmo_error_log('Quickbooks user empty');
	}
	$user_id = get_current_user_id();
	$quickbooks_credentials = get_user_meta($user_id, 'quickbooks_api', true);
	
	if( !is_array($quickbooks_credentials) && empty($quickbooks_credentials['realmId']) ){
		//die("Error: Missing access token or realm ID.");
		$qb_err = 'error';
		$sync_status = array(
			'status' => 'error',
			'message' => 'QuickBooks sync failed. Please contact support.'
		);
		update_post_meta( $post_id, 'quickbooks_shipment_sync_status', $sync_status );
		mezmo_error_log('Invalid realmId');
	}
	
	$baseUrl = 'https://sandbox-quickbooks.api.intuit.com/v3/company';
	$accessToken = quickbooks_get_vendor_access_token();
	$realmId = $quickbooks_credentials['realmId'];

	// API endpoint for creating invoices
	$invoiceUrl = "$baseUrl/$realmId/invoice";
	
	$itemId = get_user_meta($user_id, 'quickbooks_product', true);
	$item_ref_id = '';
	$qb_item = '';
	if( $itemId != '' ){
		$qb_item = quickbooks_search_item_by_id($itemId);
	}
	
	if( $qb_item == 'not_found' ){
		//error_log('Error: Invalid ItemRef ID.', 1, "xx@example.com");
		$sync_status = array(
			'status' => 'error',
			'message' => 'QuickBooks sync failed. Please contact support.'
		);
		update_post_meta( $post_id, 'quickbooks_shipment_sync_status', $sync_status );
		//die("Error: Invalid ItemRef ID.");
		$qb_err = 'error';
		mezmo_error_log( 'Invalid ItemRef ID' );
	}else{
		$item_ref_id = $qb_item['Item']['Id'];
	}
	
	if( $qb_err != 'error' ) :
	
	$line_items = json_decode($tracking_info->item_qty);
	$line = [];
	if ( $line_items ) {
		foreach ( $line_items as $item_id => $qty ) {
			$item_details = new WC_Order_Item_Product( $item_id );
			$_product     = $item_details->get_product();
			
			$item_name = $item_details['name'].' - SKU '.$_product->get_sku();
			$item_id = $_product->get_id();
			$item_qty = $qty;
			$price = $item_details->get_total();
			$quantity = $item_details->get_quantity();
			$unit_price = $price / $quantity;
			
			$amount = $unit_price * $qty;
			
			$line[] = [
				"Description" => $item_name, // Custom description
				"Amount" => $amount, // Amount for the custom line item
				"DetailType" => "SalesItemLineDetail",
				"SalesItemLineDetail" => [
					"ItemRef" => [
						"value" => "$item_ref_id" // Replace with the actual product/item ID or use 0 for non-inventory
					],
					"UnitPrice" => $unit_price, // Unit price for the custom item
					"Qty" => $item_qty, // Quantity for the custom item
				]
			];
		}
	}
	$invoice_no = $post_id.'-Shipment-'.$shipment_id;
	//invoice data 
	$invoiceData = [
		"DocNumber" => $invoice_no,
		"CurrencyRef" => [
			"value" => "USD",
			"name" => "United States Dollar"
		],
		"Line" => $line,
		"CustomerRef" => [
			"value" => "$quickbooks_user"
		]
	];

	// Convert invoice data to JSON
	$jsonData = json_encode($invoiceData);

	// Initialize cURL
	$ch = curl_init($invoiceUrl);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
	curl_setopt($ch, CURLOPT_HTTPHEADER, [
		"Authorization: Bearer $accessToken",
		"Content-Type: application/json",
		"Accept: application/json"
	]);

	// Execute API request
	$response = curl_exec($ch);
	$httpStatus = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	curl_close($ch);

	// Handle response
	if ($httpStatus === 200 || $httpStatus === 201) {
		$responseData = json_decode($response, true);
		//echo "Invoice created successfully! Invoice ID: " . $responseData['Id'];
		//error_log($responseData, 1, "xx@example.com");
		$sync_status = array(
			'status' => 'success',
			'message' => 'QuickBooks invoice sync successful. Check invoice #'.$responseData['Invoice']['Id'].' in QuickBooks.'
		);
		update_post_meta( $post_id, 'quickbooks_shipment_sync_status', $sync_status );
		mezmo_error_log($responseData);
	} else {
		
		mezmo_error_log( $response );
		
		//echo "Error: Failed to create invoice. HTTP Status: $httpStatus. Response: $response";
		$sync_status = array(
			'status' => 'error',
			'message' => 'QuickBooks sync failed. Please contact support.'
		);
		update_post_meta( $post_id, 'quickbooks_shipment_sync_status', $sync_status );
	}
	
	endif;
}

/* Quickbooks create a customer */ 
function quickbooks_create_customer($customer_details, $business_name){
	// QuickBooks API credentials and endpoints
	$baseUrl = 'https://sandbox-quickbooks.api.intuit.com/v3/company';
	
	$user_id = get_current_user_id();
	$quickbooks_credentials = get_user_meta($user_id, 'quickbooks_api', true);
	
	if( !is_array($quickbooks_credentials) && empty($quickbooks_credentials['realmId']) ){
		mezmo_error_log('Missing RealmId');
		die("Error: Missing access token or realm ID.");
	}
	
	$qb_validation = quickbooks_refresh_token_validation();
	
	if($qb_validation == 'false'){
		mezmo_error_log('Token validation error');
		die("Error: Invalid access token.");
	}
	
	$accessToken = quickbooks_get_vendor_access_token();
	$realmId = $quickbooks_credentials['realmId'];

	// API endpoint for creating an account
	$createAccountUrl = "$baseUrl/$realmId/customer";

	// Sample account data
	$accountData = [
		"FullyQualifiedName" => "$business_name",
		"PrimaryEmailAddr" => [
			"Address" => $customer_details["email"]
		],
		"DisplayName" => "$business_name",
		"PrimaryPhone" => [
			"FreeFormNumber" => $customer_details["phone"]
		],
		"GivenName" => "$business_name"
	];

	// Convert account data to JSON
	$jsonData = json_encode($accountData);

	// Initialize cURL
	$ch = curl_init($createAccountUrl);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
	curl_setopt($ch, CURLOPT_HTTPHEADER, [
		"Authorization: Bearer $accessToken",
		"Content-Type: application/json",
		"Accept: application/json"
	]);

	// Execute API request
	$response = curl_exec($ch);
	$httpStatus = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	curl_close($ch);

	// Handle response
	if ($httpStatus === 200 || $httpStatus === 201) {
		$responseData = json_decode($response, true);
		$user_id = $responseData['Customer']['Id'];
		$res = array(
			'status' => 'success',
			'userid' => $user_id,
		);
		mezmo_error_log($responseData);
		return $res;
	} else {
		return "<p style='color:red;padding:10px 20px'>Error: Failed to create account.</p>";
		mezmo_error_log( $response );
	}
}

// Quickbooks get all customers
function quickbooks_get_all_customers(){
	// QuickBooks API credentials and endpoints
	$baseUrl = 'https://sandbox-quickbooks.api.intuit.com/v3/company';
	$user_id = get_current_user_id();
	$quickbooks_credentials = get_user_meta($user_id, 'quickbooks_api', true);
	
	if( !is_array($quickbooks_credentials) && empty($quickbooks_credentials['realmId']) ){
		mezmo_error_log('Missing access token or realm ID.');
		die("Error: Missing access token or realm ID.");
	}
	
	$qb_validation = quickbooks_refresh_token_validation();
	
	if($qb_validation == 'false'){
		mezmo_error_log('Invalid access token');
		die("Error: Invalid access token.");
	}
	
	$accessToken = quickbooks_get_vendor_access_token();
	$realmId = $quickbooks_credentials['realmId'];

	if (!$accessToken || !$realmId) {
		mezmo_error_log('Missing access token or realm ID');
		die("Error: Missing access token or realm ID.");
	}

	// API endpoint for querying customers
	$getCustomersUrl = "$baseUrl/$realmId/query?query=" . urlencode("SELECT * FROM Customer");

	// Initialize cURL
	$ch = curl_init($getCustomersUrl);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_HTTPGET, true);
	curl_setopt($ch, CURLOPT_HTTPHEADER, [
		"Authorization: Bearer $accessToken",
		"Accept: application/json"
	]);

	// Execute API request
	$response = curl_exec($ch);
	$httpStatus = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	curl_close($ch);

	// Handle response
	if ($httpStatus === 200) {
		$responseData = json_decode($response, true);
		if (isset($responseData['QueryResponse']['Customer'])) {
			return $responseData['QueryResponse']['Customer'];
		} else {
			echo "No customers found.";
		}
		mezmo_error_log($responseData);
	} else {
		echo "Error: Failed to retrieve customers. HTTP Status: $httpStatus. Response: $response";
		mezmo_error_log( $response );
	}
}

// Create quickbooks product/item
function quickbooks_create_item($income_ac, $expense_ac){
	// QuickBooks API endpoint and credentials
	$baseUrl = 'https://sandbox-quickbooks.api.intuit.com/v3/company'; // Sandbox URL
	$user_id = get_current_user_id();
	$quickbooks_credentials = get_user_meta($user_id, 'quickbooks_api', true);
	
	if( !is_array($quickbooks_credentials) && empty($quickbooks_credentials['realmId']) ){
		mezmo_error_log('Missing access token or realm ID');
		die("Error: Missing access token or realm ID.");
	}
	
	$qb_validation = quickbooks_refresh_token_validation();
	
	if($qb_validation == 'false'){
		mezmo_error_log('Invalid access token');
		die("Error: Invalid access token.");
	}
	
	$accessToken = quickbooks_get_vendor_access_token();
	$realmId = $quickbooks_credentials['realmId'];

	// API endpoint for creating a product/item
	$createItemUrl = "$baseUrl/$realmId/item?minorversion=73";

	// Non-Inventory Product Data
	$productData = [
		"Name" => "Wholesale",
		"Description" => "Wholesale product.",
		"Active" => true,
		"FullyQualifiedName" => "Wholesale",
		"Taxable" => false,
		"UnitPrice" => 0, // Selling price per unit
		"Type" => "NonInventory", // Type of the item
		"PurchaseCost" => 0,
		"IncomeAccountRef" => [
			"value" => "$income_ac",
		],
		"ExpenseAccountRef" => [
			"value" => "$expense_ac",
		]
	];

	// Convert data to JSON
	$jsonData = json_encode($productData);

	// Initialize cURL
	$ch = curl_init($createItemUrl);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
	curl_setopt($ch, CURLOPT_HTTPHEADER, [
		"Authorization: Bearer $accessToken",
		"Content-Type: application/json",
		"Accept: application/json"
	]);

	// Execute the API request
	$response = curl_exec($ch);
	$httpStatus = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	curl_close($ch);

	// Handle the response
	if ($httpStatus === 200 || $httpStatus === 201) {
		$responseData = json_decode($response, true);
		$user_id = get_current_user_id();
		update_user_meta($user_id, 'quickbooks_product', $responseData['Item']['Id']);
		echo "<p style='color:green'>QuickBooks connection successful and wholesale product is ready to sync invoices.</p>";
		mezmo_error_log($responseData);
	} else {
		echo '<p style="color:red">Failed to create an item in QuickBooks. Please contact support.</p>';
		mezmo_error_log( $response );
	}
}

// Search quickbooks product by product id
function quickbooks_search_item_by_id($itemId) {
    // QuickBooks API endpoint and credentials
    $baseUrl = 'https://sandbox-quickbooks.api.intuit.com/v3/company'; // Sandbox URL
    $user_id = get_current_user_id();
    $quickbooks_credentials = get_user_meta($user_id, 'quickbooks_api', true);

    if (!is_array($quickbooks_credentials) || empty($quickbooks_credentials['realmId'])) {
		mezmo_error_log('Missing access token or realm ID');
        die("Error: Missing access token or realm ID.");
    }

    $qb_validation = quickbooks_refresh_token_validation();

    //if ($qb_validation == 'false') {
        //die("Error: Invalid access token f.");
    //}

    $accessToken = quickbooks_get_vendor_access_token();
    $realmId = $quickbooks_credentials['realmId'];

    // API endpoint for searching the product/item by ID
    $searchItemUrl = "$baseUrl/$realmId/item/$itemId?minorversion=73";

    // Initialize cURL
    $ch = curl_init($searchItemUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPGET, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer $accessToken",
        "Content-Type: application/json",
        "Accept: application/json"
    ]);

    // Execute the API request
    $response = curl_exec($ch);
    $httpStatus = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    // Handle the response
    if ($httpStatus === 200) {
        $responseData = json_decode($response, true);
		mezmo_error_log($responseData);
        return $responseData;
    } else {
        return 'not_found';
		mezmo_error_log( $response );
    }
}

// Get customer details from order
function get_customer_details_from_order($order_id) {
    // Load WooCommerce order object
    $order = wc_get_order($order_id);

    if (!$order) {
        return "Error: Order not found.";
    }

    // Get customer details
    $customer_details = [
        'customer_id'      => $order->get_user_id(),
        'first_name'       => $order->get_billing_first_name(),
        'last_name'        => $order->get_billing_last_name(),
        'email'            => $order->get_billing_email(),
        'phone'            => $order->get_billing_phone(),
        'billing_address'  => $order->get_formatted_billing_address(),
        'shipping_address' => $order->get_formatted_shipping_address(),
    ];

    return $customer_details;
}

// Function to fetch accounts
function fetchAccounts($type) {
	
	$user_id = get_current_user_id();
    $quickbooks_credentials = get_user_meta($user_id, 'quickbooks_api', true);
	
	$accessToken = quickbooks_get_vendor_access_token();
    $realmId = $quickbooks_credentials['realmId'];
	
	// QuickBooks API configuration
	$baseUrl = 'https://sandbox-quickbooks.api.intuit.com/v3/company';

	if (!$accessToken) {
		mezmo_error_log('Missing access token');
		die("Error: Missing access token.");
	}

	// SQL query
	$query = "SELECT * FROM Account WHERE AccountType = '$type'";
	$queryUrl = $baseUrl . '/' . $realmId . '/query?query=' . urlencode($query) . '&minorversion=73';

	// Initialize cURL
	$ch = curl_init($queryUrl);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_HTTPHEADER, [
		"Authorization: Bearer $accessToken",
		"Content-Type: application/json",
		"Accept: application/json"
	]);

	// Execute API request
	$response = curl_exec($ch);
	$httpStatus = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	$error = curl_error($ch);
	curl_close($ch);

	// Check for cURL errors
	if ($error) {
		mezmo_error_log('cURL Error');
		die("cURL Error: $error");
	}

	// Check response status
	if ($httpStatus === 200) {
		$data = json_decode($response, true);
		$accounts = $data['QueryResponse']['Account'] ?? [];
		return $accounts;
	} else {
		echo "Error: Failed to fetch accounts. HTTP Status: $httpStatus. Response: $response";
		mezmo_error_log( $response );
	}
}

// Disconnect QuickBooks
function disconnect_quickbooks($access_token)
{
    $revokeUrl = 'https://developer.api.intuit.com/v2/oauth2/tokens/revoke';

	// Basic Authorization Header (Base64 encoded ClientId:ClientSecret)
	$clientId = get_option('qb_client_id');
	$clientSecret = get_option('qb_client_secret');
	$authHeader = base64_encode("$clientId:$clientSecret");

	// Token to revoke (access token or refresh token)
	$token = $access_token;

	if (empty($token)) {
		mezmo_error_log('Missing token to revoke');
		return "Error: Missing token to revoke.";
	}

	// Prepare payload
	$payload = json_encode([
		"token" => $token
	]);

	// Initialize cURL
	$ch = curl_init($revokeUrl);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
	curl_setopt($ch, CURLOPT_HTTPHEADER, [
		"Content-Type: application/json",
		"Accept: application/json",
		"Authorization: Basic $authHeader"
	]);

	// Execute API request
	$response = curl_exec($ch);
	$httpStatus = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	$error = curl_error($ch);
	curl_close($ch);

	// Debugging
	if ($error) {
		mezmo_error_log('cURL Error');
		die("cURL Error: $error");
	}

	// Handle response
	if ($httpStatus === 200) {
		$user_id = get_current_user_id();
		$quickbooks_api = array(
			'access_token' => '',
			'refresh_token' => '',
			'realmId' => '',
		);
		update_user_meta($user_id, 'quickbooks_api',array());
		echo "<p style='color:green'>QuickBooks successfully disconnected.</p> <br>";
		mezmo_error_log($response);
	} else {
		echo "<p style='color:red'>Failed to disconnect QuickBooks. Please contact support. <br>";
		mezmo_error_log( $response );
	}
}