<div class="dokan-panel dokan-panel-default">
    <div class="dokan-panel-heading">
        <strong><?php esc_html_e( 'Shipments', 'dokan' ); ?></strong>
    </div>
    <div class="dokan-panel-body" id="dokan-order-shipping-status-tracking-panel">
		<?php
		$refresh_token_validation = quickbooks_refresh_token_validation();
		?>
		
		<?php if( $refresh_token_validation == 'true' ): ?>
		<!-- QuickBooks User setup -->
		<style>
			.quickbooks-user-account form{
				padding: 10px;
			}
			.quickbooks-user-account form .qb_user_field_wrap {
				display: flex;
				text-align: left;
				flex-direction: row;
				flex-wrap: wrap;
				align-items: center;
				justify-content: space-between;
			}
		</style>
		<?php
		if( isset($_POST['quickbooks_customer_save']) ){
			$quickbooks_customer = $_POST['quickbooks_customer'];
			update_post_meta( $_GET['order_id'], 'quickbooks_customer', sanitize_text_field($quickbooks_customer) );
			mezmo_error_log('Customer saved successfully');
		}
		?>
		
		<?php 
		$customer_details = get_customer_details_from_order($_GET['order_id']); 
		$business_name = get_user_meta( $customer_details['customer_id'], 'licensed_business_name', true );
		if( isset($_POST['add_customer_to_qb']) ){
			$result = quickbooks_create_customer($customer_details, $business_name);
			if( is_array($result) ){
				echo "<p style='color:green;padding:10px 20px'>Account created successfully!</p>";
				//print_r( $result['userid'] );
				update_post_meta( $_GET['order_id'], 'quickbooks_customer', $result['userid'] );
				mezmo_error_log('Account created successfully');
			}else{
				echo $result;
			}
		}
		?>
		
		<div class="quickbooks-user-account">
			<label style="padding:20px 10px"><strong>QuickBooks Customer Mapping</strong></label>
			<div style="display:none" class="qb-user-mapping-form">
			<form style='' method="post" action="">
				<label><strong>Create new customer in Quickbooks</strong></label>
				<p style='margin-bottom: 5px'>If the customer does not exist in the QuickBooks customer dropdown, add the order's customer, <strong><?php echo esc_html($business_name); ?></strong>, to QuickBooks.</p>
				<input class="button custom-design dokan-btn-theme" name="add_customer_to_qb" type="submit" value="Add Customer to QuickBooks">
				<p>
					<br><a class="qb-add-existing-list" href="#">Add user from an existing QuickBooks list</a>
				</p>
			</form>
			</div>
			<br>
			<form method="post" action="" class="qb-existing-user-adding">
				<label><strong>Map existing customer in QuickBooks</strong></label>
				<p style='margin-bottom: 5px'>Assign your QuickBooks customer to this order.</p>
				<div class="qb_user_field_wrap">
					<div style="display:inline-block; width:47%">
						<?php $quickbooks_customer = get_post_meta( $_GET['order_id'], 'quickbooks_customer', true ); ?>
						<select name="quickbooks_customer">
							<option value="">-Select QuickBooks Customer-</option>
						<?php
						$quickbooks_customers = quickbooks_get_all_customers();
						if( is_array($quickbooks_customers) ){
							foreach ($quickbooks_customers as $customer) {
								echo '<option '.selected($quickbooks_customer, $customer['Id']).' value="'.esc_attr($customer['Id']).'">'.esc_html($customer['DisplayName']).'</option>';
							}
						}
						?>
						</select>
						
					</div>
					<div style="display:inline-block;width:52%;text-align: right;">
						<input type="submit" name="quickbooks_customer_save" value="Save QuickBooks Customer">
					</div>
				</div>
				<p>
					<a href="#" class="qb-add-new-customer">Add new customer if not exist</a>
				</p>
			</form>
			
			<script>
				jQuery('.qb-add-new-customer').on('click', function(e){
					e.preventDefault();
					jQuery('.qb-existing-user-adding').hide();
					jQuery('.qb-user-mapping-form').show();
				});
				jQuery('.qb-add-existing-list').on('click', function(e){
					e.preventDefault();
					jQuery('.qb-user-mapping-form').hide();
					jQuery('.qb-existing-user-adding').show();
				});
			</script>
			
		</div>
		<hr>
		<?php endif; ?>
		
		<?php  
		if( $refresh_token_validation == 'false' ){
			echo '<p style="color:red;padding:10px 20px">QuickBooks is not connected. Please <a style="color:blue" href="/dashboard/quickbooks/">verify</a> the connection settings to enable sending shipments to QuickBooks.</p><hr>';
		}
		?>
		
        <div id="dokan-order-shipping-status-tracking-shippments">
            <?php
            /**
             * @var WC_Order $order Order.
             */
            $incre        = 1;
            $s_line_items = [];
            if ( $shipment_info ) :
                foreach ( $shipment_info as $key => $shipment ) :
                    $shipment_id             = $shipment->id;
                    $order_id                = $shipment->order_id;
                    $provider                = $shipment->provider;
                    $provider_label          = $shipment->provider_label;
                    $number                  = $shipment->number;
                    $date                    = $shipment->date;
                    $status_label            = $shipment->status_label;
                    $shipping_status         = $shipment->shipping_status;
                    $provider_url            = $shipment->provider_url;
                    $item_qty                = json_decode( $shipment->item_qty );
                    $is_editable             = true;
                    $shipment_timeline       = dokan_pro()->shipment->custom_get_order_notes( $order_id, $shipment_id );
                    $recipient_status        = $order->get_meta( 'dokan_customer_order_receipt_status' );
                    $non_editable_statuses   = [ 'ss_delivered', 'ss_cancelled' ];
                    $shipment_marked_receive = \WeDevs\DokanPro\Shipping\Helper::is_order_marked_as_received( $order_id, $shipment_id );

                    if ( $shipment_marked_receive ) {
                        $shipping_status         = $shipment_marked_receive ? 'ss_mark_received' : $shipping_status;
                        $non_editable_statuses[] = 'ss_mark_received';
                    }

                    if ( in_array( $shipping_status, $non_editable_statuses, true ) ) {
                        $is_editable = false;
                    }

                    if ( $allowed_mark_receive ) { // Check mark as received allowed for customers.
                        // Ignore mark as received status from vendor shipment if not received.
                        foreach ( $status_list as $key => $s_status ) {
                            if ( ! $shipment_marked_receive && $s_status['id'] === 'ss_mark_received' ) {
                                unset( $status_list[ $key ] );
                                break; // Exit the loop once the item is found and removed
                            }
                        }

                        $shipment_statuses = wp_list_pluck( $status_list, 'id' );
                        // If shipment_marked_receive is true and 'ss_mark_received' is not in the array, add it
                        if ( $shipment_marked_receive && ! in_array( 'ss_mark_received', $shipment_statuses, true ) ) {
                            $status_list[] = array(
                                'id'    => 'ss_mark_received',
                                'value' => __( 'Received', 'dokan' ),
                            );
                        }
                    }

                    dokan_get_template_part(
                        'orders/shipment/html-vendor-shipment-item', '', array(
                            'pro'                 => true,
                            'shipment_id'         => $shipment_id,
                            'order_id'            => $order_id,
                            'provider'            => $provider,
                            'provider_label'      => $provider_label,
                            'number'              => $number,
                            'date'                => $date,
                            'status_label'        => $status_label,
                            'shipping_status'     => $shipping_status,
                            'provider_url'        => $provider_url,
                            'item_qty'            => $item_qty,
                            'order'               => $order,
                            'line_items'          => $line_items,
                            'incre'               => $incre,
                            'status_list'         => $status_list,
                            's_providers'         => $s_providers,
                            'd_providers'         => $d_providers,
                            'is_editable'         => $is_editable,
                            'customer_status'     => $recipient_status,
                            'shipment_timeline'   => $shipment_timeline,
                            'disabled_update_btn' => $disabled_create_btn,
                        )
                    );

                    $incre++;
                endforeach;
            endif;
            ?>
            <input type="hidden" name="security_update" id="security_update" value="<?php echo esc_attr( wp_create_nonce( 'update-shipping-status-tracking-info' ) ); ?>">
        </div><!-- .dokan-shippments-body -->
        <div class="dokan-hide" id="dokan-order-shipping-status-tracking">
            <?php if ( ! $is_shipped ) : ?>
                <form id="add-shipping-tracking-status-form" method="post" class="dokan-tracking-status-form" style="padding: 15px;">
                    <div class="woocommerce_order_items_wrapper wc-order-items-editable">
                        <table cellpadding="0" cellspacing="0" class="woocommerce_order_items dokan-table dokan-table-strip">
                            <thead>
                                <tr>
                                    <th></th>
                                    <th class="item sortable" data-sort="string-ins" width="15%"><?php esc_html_e( 'Item', 'dokan' ); ?></th>
                                    <th class="title sortable" data-sort="int">&nbsp;</th>
                                    <th class="quantity sortable" data-sort="int"><?php esc_html_e( 'Qty', 'dokan' ); ?></th>
                                </tr>
                            </thead>
                            <tbody id="order_line_items">
                            <?php
                            foreach ( $line_items as $item_id => $item ) {
                                if ( dokan_pro()->shipment->get_status_order_item_shipped( $order_id, $item_id, $item['qty'] ) ) {
                                    continue;
                                }

                                if ( version_compare( WC_VERSION, '4.4.0', '>=' ) ) {
                                    $_product = $item->get_product();
                                } else {
                                    $_product = $order->get_product_from_item( $item );
                                }

                                dokan_get_template_part(
                                    'orders/shipment/html-vendor-shipment-product-item', '', array(
                                        'pro'          => true,
                                        'order'        => $order,
                                        'item'         => $item,
                                        'item_id'      => $item_id,
                                        'order_id'     => $order_id,
                                        '_product'     => $_product,
                                    )
                                );
                            }
                            ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="dokan-form-group">
                        <label class="dokan-control-label"><?php esc_html_e( 'Shipping Status', 'dokan' ); ?></label>
                        <select name="shipping_status" id="shipment-status" class="dokan-form-control" style="width:50%;">
                            <option value=""><?php esc_html_e( 'Select', 'dokan' ); ?></option>
                            <?php if ( ! empty( $status_list ) ) : ?>
                                <?php
                                foreach ( $status_list as $s_status ) :
                                    $s_status['value'] = apply_filters( 'dokan_pro_shipping_status', $s_status['value'] );
                                    ?>
                                    <option value="<?php echo esc_attr( $s_status['id'] ); ?>"><?php echo esc_html( $s_status['value'] ); ?></option>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <hr>
                    <h4 class="shipping-status-track-info-heading"><strong><?php esc_html_e( 'Tracking Information', 'dokan' ); ?></strong></h4>

                    <div class="dokan-form-group shipping-status-provider">
                        <label class="dokan-control-label"><?php esc_html_e( 'Shipping Provider', 'dokan' ); ?></label>
                        <select name="shipping_status_provider" id="shipping_status_provider" class="dokan-form-control select2">
                            <option value=""><?php esc_html_e( 'Select', 'dokan' ); ?></option>
                            <?php foreach ( $s_providers as $k_provider => $provider ) : ?>
								<?php 
								$provider_state = get_shipping_provider_state_by_slug($k_provider);
								$user_state = get_user_meta( get_current_user_id(), 'state', true );
								?>
                                <?php if ( ! empty( $provider ) && isset( $d_providers[ $k_provider ] ) ) : ?>
								<?php if( $user_state == $provider_state ) : ?>
                                    <option value="<?php echo esc_attr( $k_provider ); ?>"><?php echo esc_html( $d_providers[ $k_provider ] ); ?></option>
								<?php endif; ?>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="dokan-form-group shipped-status-date">
                        <label class="dokan-control-label"><?php esc_html_e( 'Date Shipped', 'dokan' ); ?></label>
                        <input type="text" data-ordered-date="<?php echo esc_attr( $order->get_date_created() ); ?>"
                            name="shipped_status_date" id="shipped_status_date" class="dokan-form-control shipped_status_date"
                            value="" autocomplete="off" placeholder="<?php esc_attr_e( 'Select date', 'dokan' ); ?>" />
                    </div>
                    <div class="dokan-form-group shipped-tracking-number">
                        <label class="dokan-control-label tracking-status-number-label"><?php esc_html_e( 'Tracking Number', 'dokan' ); ?></label>
                        <input type="text" name="tracking_status_number" id="tracking_status_number" class="dokan-form-control" value="">
                    </div>
                    <div class="tracking-status-other-url dokan-hide">
                        <div class="dokan-form-group tracking-status-other-provider">
                            <label class="dokan-control-label tracking-status-url-label"><?php esc_html_e( 'Provider Name', 'dokan' ); ?></label>
                            <input type="text" name="tracking_status_other_provider" id="tracking_status_other_provider" class="dokan-form-control" autocomplete="off" value="">
                        </div>
                        <div class="dokan-form-group tracking-status-other-p-url">
                            <label class="dokan-control-label tracking-status-url-label"><?php esc_html_e( 'Tracking URL', 'dokan' ); ?></label>
                            <input type="text" name="tracking_status_other_p_url" id="tracking_status_other_p_url" class="dokan-form-control" autocomplete="off" value="">
                        </div>
                    </div>
                    <div class="dokan-form-group shipping-tracking-comments">
                        <label class="dokan-control-label tracking-status-url-label"><?php esc_html_e( 'Comments', 'dokan' ); ?></label>
                        <textarea name="tracking_status_comments" id="tracking_status_comments" class="dokan-form-control" rows="2" cols="2"></textarea>
                    </div>
                    <div class="dokan-form-group shipped-status-is-notify">
                        <label class="dokan-control-label" for="shipped_status_is_notify">
                            <input type="checkbox" name="is_notify" id="shipped_status_is_notify" value="on">
                            <?php esc_html_e( 'Notify shipment details to customer', 'dokan' ); ?>
                        </label>
                    </div>
<!--                     <div class="dokan-form-group send_to_qb">
                        <label class="dokan-control-label" for="send_to_qb">
                            <input type="checkbox" name="send_to_qb" id="send_to_qb" value="on">
                            <?php esc_html_e( 'Send to quickbooks', 'dokan' ); ?>
                        </label>
                    </div> -->
                    <input type="hidden" name="security" id="security" value="<?php echo esc_attr( wp_create_nonce( 'add-shipping-status-tracking-info' ) ); ?>">
                    <input type="hidden" name="post_id" id="post-id" value="<?php echo esc_attr( $order_id ); ?>">
                    <input type="hidden" name="action" id="action" value="dokan_add_shipping_status_tracking_info">

                    <div class="dokan-form-group">
                        <input id="add-tracking-status-details" type="button" class="btn btn-primary" value="<?php esc_attr_e( 'Create Shipment', 'dokan' ); ?>">
                        <input id="cancel-tracking-status-details" type="button" class="btn btn-primary" value="<?php esc_attr_e( 'Cancel', 'dokan' ); ?>">
                    </div>
                    <p id="shipment-update-response-area"> </p>
                </form>
            <?php endif ?>
        </div>
		<?php 
		$sync_status = get_post_meta( $_GET['order_id'], 'quickbooks_shipment_sync_status', true);
		if( is_array($sync_status) && $sync_status['status'] == 'success' ){
			echo '<p style="padding: 10px 20px; color:green">'.esc_html($sync_status['message']).'</p>';
			update_post_meta( $_GET['order_id'], 'quickbooks_shipment_sync_status', '' );
		}
		if( is_array($sync_status) && $sync_status['status'] == 'error' ){
			echo '<p style="padding: 10px 20px; color:red">'.esc_html($sync_status['message']).'</p>';
			update_post_meta( $_GET['order_id'], 'quickbooks_shipment_sync_status', '' );
		}
		?>
        <?php
            $info_class = ! empty( $shipment_info ) && ! $is_shipped ? 'info-not-shipment-yet' : '';
        ?>
        <div class="shipping-status-tracking-top-info <?php echo esc_attr( $info_class ); ?>">
            <?php if ( empty( $shipment_info ) ) : ?>
                <p class="no-shipment-found-desc"><?php esc_html_e( 'No shipment found', 'dokan' ); ?></p>
            <?php endif; ?>

            <?php if ( ! $is_shipped && ! $disabled_create_btn ) : ?>
                <button id="create-tracking-status-action" type="button" class="dokan-btn dokan-btn-theme create-shipping-tracking"><?php esc_html_e( 'Create New Shipment', 'dokan' ); ?></button>
            <?php endif ?>
        </div>
    </div> <!-- .dokan-panel-body -->
</div> <!-- .dokan-panel -->
