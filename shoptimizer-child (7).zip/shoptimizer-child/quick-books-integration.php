<?php
// Exit if accessed directly
if (!defined('ABSPATH')) exit;

/**
 *  Dokan Dashboard Template
 *
 *  Dokan Main Dahsboard template for Fron-end
 *
 *  @since 2.4
 *
 *  @package dokan
 */
?>
<?php do_action( 'dokan_dashboard_wrap_start' ); ?>
<div class="dokan-dashboard-wrap">
    <?php
        /**
         *  dokan_dashboard_content_before hook
         *
         *  @hooked get_dashboard_side_navigation
         *
         *  @since 2.4
         */
        do_action( 'dokan_dashboard_content_before' );
    ?>

    <div class="dokan-dashboard-content">

        <?php
            /**
             *  dokan_dashboard_content_before hook
             *
             *  @hooked show_seller_dashboard_notice
             *
             *  @since 2.4
             */
            do_action( 'dokan_help_content_inside_before' );
        ?>
		<?php
		session_start();

		// Replace these with your actual credentials
		$clientId = get_option('qb_client_id'); //'ABjxUlpES84cje2Pse9UNgjTVenUMrc2jRbn5SUqTqrRTdxtm3';
		$clientSecret = get_option('qb_client_secret'); //'pNo2M5B7nGRbaMyYzL9LKlBhuObwBtCsQP54wl8C';
		$redirectUri = get_option('qb_redirect_url'); //'https://dev.overagemart.com/dashboard/quickbooks/';
		$authUrl = 'https://appcenter.intuit.com/connect/oauth2';
		$tokenUrl = 'https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer';
		$scope = 'com.intuit.quickbooks.accounting';

		// Login route
		if (isset($_GET['action']) && $_GET['action'] === 'login') {
			$state = bin2hex(random_bytes(8));
			$_SESSION['oauth2_state'] = $state;

			$queryParams = http_build_query([
				'client_id' => $clientId,
				'response_type' => 'code',
				'scope' => $scope,
				'redirect_uri' => $redirectUri,
				'state' => $state,
			]);

			header("Location: $authUrl?$queryParams");
			exit;
		}

		// Callback route
		if (isset($_GET['code']) && isset($_GET['state'])) {
			if ($_GET['state'] !== $_SESSION['oauth2_state']) {
				header("Location: /dashboard/quickbooks/");
				mezmo_error_log('Invalid state parameter');
				die('Error: Invalid state parameter');
			}

			$code = $_GET['code'];

			$authHeader = base64_encode("$clientId:$clientSecret");

			$postFields = [
				'grant_type' => 'authorization_code',
				'code' => $code,
				'redirect_uri' => $redirectUri,
			];

			$ch = curl_init($tokenUrl);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postFields));
			curl_setopt($ch, CURLOPT_HTTPHEADER, [
				"Authorization: Basic $authHeader",
				'Content-Type: application/x-www-form-urlencoded',
			]);

			$response = curl_exec($ch);
			$httpStatus = curl_getinfo($ch, CURLINFO_HTTP_CODE);
			curl_close($ch);

			if ($httpStatus !== 200) {
				mezmo_error_log( $response );
				header("Location: /dashboard/quickbooks/");
				exit;
			}else{
				$tokenData = json_decode($response, true);
				$_SESSION['access_token'] = $tokenData['access_token'];
				$_SESSION['refresh_token'] = $tokenData['refresh_token'];

				if( isset($_GET['realmId']) ){
					$quickbooks_api = array(
						'access_token' => $tokenData['access_token'],
						'refresh_token' => $tokenData['refresh_token'],
						'realmId' => $_GET['realmId'],
					);

					$user_id = get_current_user_id();

					update_user_meta($user_id, 'quickbooks_api', $quickbooks_api);
					
					mezmo_error_log($tokenData);
					//Create quickbooks default product : OverageMart sales
					//quickbooks_create_item();
				}
			}
			
			//echo "Access token: " . $tokenData['access_token'] . "<br>Refresh token: " . $tokenData['refresh_token'];
			//exit;
		}

		// Refresh token route
		if (isset($_GET['action']) && $_GET['action'] === 'refresh') {
			if (!isset($_SESSION['refresh_token'])) {
				die('Error: No refresh token found.');
			}

			$refreshToken = $_SESSION['refresh_token'];

			$authHeader = base64_encode("$clientId:$clientSecret");

			$postFields = [
				'grant_type' => 'refresh_token',
				'refresh_token' => $refreshToken,
			];

			$ch = curl_init($tokenUrl);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postFields));
			curl_setopt($ch, CURLOPT_HTTPHEADER, [
				"Authorization: Basic $authHeader",
				'Content-Type: application/x-www-form-urlencoded',
			]);

			$response = curl_exec($ch);
			$httpStatus = curl_getinfo($ch, CURLINFO_HTTP_CODE);
			curl_close($ch);

			if ($httpStatus !== 200) {
				mezmo_error_log( $response );
				die('Error: Failed to refresh token: ' . $response);
			}

			$tokenData = json_decode($response, true);
			$_SESSION['access_token'] = $tokenData['access_token'];
			$_SESSION['refresh_token'] = $tokenData['refresh_token'];

			//echo "New access token: " . $tokenData['access_token'] . "<br>New refresh token: " . $tokenData['refresh_token'];

			exit;
		}

		// Default route
		?>
		<div>
			<h1>QuickBooks Integration</h1>
			<?php
			
			//Disconnect quickbooks
			if( isset($_GET['disconnect']) && $_GET['disconnect'] == 'yes' ){
				$accessToken = quickbooks_get_vendor_access_token();
				//echo $accessToken;
				disconnect_quickbooks($accessToken);
			}
			
			$get_quickbooks_api = get_user_meta(get_current_user_id(), 'quickbooks_api', true);
			
			if( !empty($get_quickbooks_api) && is_array($get_quickbooks_api) ){
				$refresh_token = $get_quickbooks_api['refresh_token'];
			}else{
				$refresh_token = '';
			}
			if( $refresh_token != '' ){
				$refresh_token_validation = quickbooks_refresh_token_validation();
			}
			?>
			<?php 
			if($refresh_token_validation == 'true'){
				if(isset($_GET['state'])){
					header("Location: /dashboard/quickbooks/");
					exit;
				}
				
				echo '<p>QuickBooks Online Connection Status is <strong>Active</strong></p>';

				if( isset($_POST['create_product']) ){
					$income_ac = $_POST['income_account'];
					$expense_ac = $_POST['expense_account'];
					if( $income_ac != '' && $expense_ac != '' ){
						mezmo_error_log('Creating quickbooks item');
						quickbooks_create_item($income_ac, $expense_ac);
					}
				}
				
				$user_id = get_current_user_id();
				$itemId = get_user_meta($user_id, 'quickbooks_product', true);
				
				//if( $itemId != '' ){
				$qb_item = quickbooks_search_item_by_id($itemId);
				if( $qb_item == 'not_found' ){
					mezmo_error_log('Item Not Found');
					//Create quickbooks default product : OverageMart sales
					?>
					<form method="post" action="" class="ac_type_form">
						<?php $income_accounts = fetchAccounts('Income'); ?>
						<?php $expense_accounts = fetchAccounts('Expense'); ?>
						<h3>
							Create your wholesale sales item
						</h3>
						<p>
							The SKU ID, product, and variant names will appear in your QuickBooks invoice under this wholesale product.
						</p>
						<div class="ac_types">
							<div>
								<?php if( is_array($income_accounts) ) : ?>
								<label>Select the income account</label>
								<select name="income_account">
									<option value="">-Select-</option>
									<?php foreach( $income_accounts as $income_account ): ?>
									<option value="<?php echo esc_attr($income_account['Id']); ?>"><?php echo esc_html($income_account['Name']); ?></option>
									<?php endforeach; ?>
								</select>
								<?php endif; ?>
							</div>
							<div>
								<?php if( is_array($expense_accounts) ) : ?>
								<label>Select the expense account</label>
								<select name="expense_account">
									<option value="">-Select-</option>
									<?php foreach( $expense_accounts as $expense_account ): ?>
									<option value="<?php echo esc_attr($expense_account['Id']); ?>"><?php echo esc_html($expense_account['Name']); ?></option>
									<?php endforeach; ?>
								</select>
								<?php endif; ?>
							</div>
						</div>
						<input type="submit" name="create_product" value="Create Product">
					</form>
					<?php
				}else {
					echo '<p>Please find orders of OverageMart under this QuickBooks item: <strong>'.$qb_item['Item']['Name'].'</strong></p>';
				}
				//}
				//Disconnect quickbooks
				echo '<hr>';
				echo '<p>Please click below to disconnect your QuickBooks Online account from OverageMart.
You will be able to reconnect again. Previously synced invoices will remain in QuickBooks Online after you disconnect. You must reconnect in order to sync invoices again.</p>';
				echo '<a class="button dokan-btn-theme" href="?disconnect=yes">Disconnect QuickBooks</a>';
				
			}else{
				echo '<a class="button" href="?action=login">Connect to QuickBooks</a><br>';
			}
			?>
			<!-- <a href="?action=refresh">Refresh Token</a> -->
		</div>
         <?php
            /**
             *  dokan_dashboard_content_inside_after hook
             *
             *  @since 2.4
             */
            do_action( 'dokan_dashboard_content_inside_after' );
        ?>


    </div><!-- .dokan-dashboard-content -->

    <?php
        /**
         *  dokan_dashboard_content_after hook
         *
         *  @since 2.4
         */
        do_action( 'dokan_dashboard_content_after' );
    ?>

</div><!-- .dokan-dashboard-wrap -->
<?php do_action( 'dokan_dashboard_wrap_end' ); ?>